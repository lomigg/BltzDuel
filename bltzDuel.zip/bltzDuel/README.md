# bltzDuel

1v1 RTP Duel plugin — Queue, Challenge, K/D Stats, Spectate.

## Features
- ⚔ **Auto matchmaking queue** — FIFO, ghép 2 người đầu tiên
- 🎯 **Direct challenge** — Thách đấu trực tiếp với `/duel challenge`
- 📊 **K/D Stats + Top 10** — Persistent stats.yml
- 👁 **Spectate** — Xem trận đấu của người khác
- 🔒 **Combat tag** — Chặn /home /tp khi đang đấu
- 💀 **Logout forfeit** — Log out trong combat = thua
- ✨ **Particle + sound** effects

## Commands

| Lệnh | Mô tả |
|------|-------|
| `/duel queue` | Vào hàng chờ ghép cặp |
| `/duel leave` | Rời hàng chờ |
| `/duel challenge <player>` | Thách đấu trực tiếp |
| `/duel accept` | Chấp nhận thách đấu |
| `/duel deny` | Từ chối thách đấu |
| `/duel spectate <player>` | Xem trận đấu |
| `/duel stats [player]` | Xem K/D stats |
| `/duel top` | Leaderboard Top 10 |
| `/duel pos` | Vị trí trong hàng chờ |
| `/duel help` | Danh sách lệnh |

Aliases: `/d`, `/pvp`

## Placeholders (PAPI)
| Placeholder | Mô tả |
|-------------|-------|
| `%bltzduel_wins%` | Số win |
| `%bltzduel_losses%` | Số thua |
| `%bltzduel_kd%` | K/D ratio |
| `%bltzduel_matches%` | Tổng trận |
| `%bltzduel_in_match%` | Đang trong trận? |
| `%bltzduel_in_queue%` | Đang trong queue? |
| `%bltzduel_queue_pos%` | Vị trí queue |
| `%bltzduel_queue_size%` | Số người trong queue |
| `%bltzduel_active_matches%` | Số trận đang diễn ra |

## Build
```bash
mvn clean package
```
Output: `target/bltzDuel-1.0.0.jar`

## Compatibility
| Software | Version |
|----------|---------|
| Spigot / Paper | 1.20.x |
| Java | 17+ |
