package com.bltz.duel.listeners;

import com.bltz.duel.services.MatchService;
import com.bltz.duel.services.QueueService;
import com.bltz.duel.services.SpectateService;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class PlayerSessionListener implements Listener {

    private final MatchService   matchService;
    private final QueueService   queueService;
    private final SpectateService spectateService;

    public PlayerSessionListener(MatchService matchService,
                                  QueueService queueService,
                                  SpectateService spectateService) {
        this.matchService    = matchService;
        this.queueService    = queueService;
        this.spectateService = spectateService;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        cleanup(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onKick(PlayerKickEvent event) {
        cleanup(event.getPlayer());
    }

    private void cleanup(Player player) {
        var uuid = player.getUniqueId();
        queueService.removeFromQueue(uuid);
        matchService.handleLogout(uuid, player.getName());
        if (spectateService.isSpectating(uuid)) {
            spectateService.stopSpectating(player);
        }
    }
}
