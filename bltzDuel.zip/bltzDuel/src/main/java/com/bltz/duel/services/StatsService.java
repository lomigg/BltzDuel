package com.bltz.duel.services;

import com.bltz.duel.BltzDuel;
import com.bltz.duel.models.PlayerStats;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;

public final class StatsService {

    private final BltzDuel plugin;
    private final File      statsFile;
    private final Map<UUID, PlayerStats> cache = new HashMap<>();

    public StatsService(BltzDuel plugin) {
        this.plugin    = plugin;
        this.statsFile = new File(plugin.getDataFolder(), "stats.yml");
        load();
    }

    // -----------------------------------------------------------------------

    public PlayerStats getStats(UUID uuid, String name) {
        return cache.computeIfAbsent(uuid, id -> new PlayerStats(id, name, 0, 0));
    }

    public void recordWin(UUID uuid, String name) {
        PlayerStats s = getStats(uuid, name);
        s.setLastName(name);
        s.addWin();
    }

    public void recordLoss(UUID uuid, String name) {
        PlayerStats s = getStats(uuid, name);
        s.setLastName(name);
        s.addLoss();
    }

    public List<PlayerStats> getTopPlayers(int limit) {
        return cache.values().stream()
                .filter(s -> s.getTotalMatches() > 0)
                .sorted(Comparator.comparingInt(PlayerStats::getWins).reversed()
                        .thenComparingDouble(PlayerStats::getKD).reversed())
                .limit(limit)
                .toList();
    }

    // -----------------------------------------------------------------------

    private void load() {
        if (!statsFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(statsFile);
        var section = yml.getConfigurationSection("stats");
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            try {
                UUID uuid   = UUID.fromString(key);
                String name = section.getString(key + ".name", "Unknown");
                int wins    = section.getInt(key + ".wins",   0);
                int losses  = section.getInt(key + ".losses", 0);
                cache.put(uuid, new PlayerStats(uuid, name, wins, losses));
            } catch (IllegalArgumentException ignored) {}
        }
        plugin.getLogger().info("Loaded stats for " + cache.size() + " player(s).");
    }

    public void saveAll() {
        YamlConfiguration yml = new YamlConfiguration();
        for (PlayerStats s : cache.values()) {
            String path = "stats." + s.getUuid();
            yml.set(path + ".name",   s.getLastName());
            yml.set(path + ".wins",   s.getWins());
            yml.set(path + ".losses", s.getLosses());
        }
        try {
            statsFile.getParentFile().mkdirs();
            yml.save(statsFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save stats.yml", e);
        }
    }
}
