package com.bltz.duel.models;

import java.util.UUID;

public final class QueueEntry {
    private final UUID playerUUID;
    private final long joinedAt;

    public QueueEntry(UUID playerUUID) {
        this.playerUUID = playerUUID;
        this.joinedAt   = System.currentTimeMillis();
    }

    public UUID getPlayerUUID() { return playerUUID; }
    public long getJoinedAt()   { return joinedAt;   }
}
