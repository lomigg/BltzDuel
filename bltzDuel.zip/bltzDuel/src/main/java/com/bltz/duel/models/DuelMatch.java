package com.bltz.duel.models;

import org.bukkit.Location;

import java.util.UUID;

/**
 * Represents an active 1v1 duel match.
 */
public final class DuelMatch {

    public enum State { STARTING, ACTIVE, ENDED }

    private final UUID     player1;
    private final UUID     player2;
    private final Location origin1;
    private final Location origin2;
    private final long     startedAt;
    private State          state = State.STARTING;

    // Combat tag timestamps
    private long lastCombat1 = 0L;
    private long lastCombat2 = 0L;

    public DuelMatch(UUID player1, UUID player2,
                     Location origin1, Location origin2) {
        this.player1   = player1;
        this.player2   = player2;
        this.origin1   = origin1.clone();
        this.origin2   = origin2.clone();
        this.startedAt = System.currentTimeMillis();
    }

    // -----------------------------------------------------------------------

    public UUID     getPlayer1()  { return player1;  }
    public UUID     getPlayer2()  { return player2;  }
    public Location getOrigin1()  { return origin1.clone(); }
    public Location getOrigin2()  { return origin2.clone(); }
    public long     getStartedAt(){ return startedAt; }
    public State    getState()    { return state;     }
    public void     setState(State s) { this.state = s; }

    public boolean involves(UUID uuid) {
        return player1.equals(uuid) || player2.equals(uuid);
    }

    public UUID getOpponent(UUID uuid) {
        if (uuid.equals(player1)) return player2;
        if (uuid.equals(player2)) return player1;
        return null;
    }

    public Location getOrigin(UUID uuid) {
        if (uuid.equals(player1)) return getOrigin1();
        if (uuid.equals(player2)) return getOrigin2();
        return null;
    }

    // -----------------------------------------------------------------------
    //  Combat tag
    // -----------------------------------------------------------------------

    public void tagCombat(UUID uuid) {
        long now = System.currentTimeMillis();
        if (uuid.equals(player1)) lastCombat1 = now;
        else if (uuid.equals(player2)) lastCombat2 = now;
    }

    public boolean isCombatTagged(UUID uuid, long expireMs) {
        long last = uuid.equals(player1) ? lastCombat1 : lastCombat2;
        return last > 0 && (System.currentTimeMillis() - last) < expireMs;
    }

    public long getDurationSeconds() {
        return (System.currentTimeMillis() - startedAt) / 1000L;
    }
}
