package com.bltz.duel.services;

import com.bltz.duel.BltzDuel;
import com.bltz.duel.models.DuelMatch;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages players spectating active duels.
 *
 * Spectators are set to SPECTATOR gamemode and teleported
 * near one of the fighters. On match end or manual leave,
 * they are returned to their original location and gamemode.
 */
public final class SpectateService {

    private final BltzDuel plugin;

    /** spectator UUID → UUID of player being watched */
    private final Map<UUID, UUID> spectators = new ConcurrentHashMap<>();

    /** spectator UUID → pre-spectate state */
    private final Map<UUID, SpectateState> savedStates = new ConcurrentHashMap<>();

    public SpectateService(BltzDuel plugin) {
        this.plugin = plugin;
    }

    // -----------------------------------------------------------------------

    /**
     * Starts spectating the match containing the target player.
     *
     * @return false if target is not in a match or spectator is in a match.
     */
    public boolean startSpectating(Player spectator, Player target, DuelMatch match) {
        if (match == null) return false;
        if (spectators.containsKey(spectator.getUniqueId())) {
            stopSpectating(spectator);
        }

        // Save current state
        savedStates.put(spectator.getUniqueId(),
                new SpectateState(spectator.getLocation().clone(),
                        spectator.getGameMode()));

        spectators.put(spectator.getUniqueId(), target.getUniqueId());

        // Apply spectator mode
        String modeStr = plugin.getConfig().getString("spectate.mode", "SPECTATOR");
        GameMode mode;
        try { mode = GameMode.valueOf(modeStr.toUpperCase()); }
        catch (Exception e) { mode = GameMode.SPECTATOR; }
        spectator.setGameMode(mode);

        // Teleport near target
        spectator.teleport(target.getLocation().add(0, 2, 0));

        String msg = plugin.getConfig().getString("messages.spectate-join",
                "§7You are now spectating §e{p1} §7vs §e{p2}§7.");
        Player p1 = plugin.getServer().getPlayer(match.getPlayer1());
        Player p2 = plugin.getServer().getPlayer(match.getPlayer2());
        msg = msg.replace("{p1}", p1 != null ? p1.getName() : "?")
                 .replace("{p2}", p2 != null ? p2.getName() : "?");
        spectator.sendMessage(msg);

        return true;
    }

    /**
     * Stops spectating and returns player to their saved state.
     */
    public void stopSpectating(Player spectator) {
        UUID uuid = spectator.getUniqueId();
        spectators.remove(uuid);

        SpectateState state = savedStates.remove(uuid);
        if (state != null) {
            spectator.setGameMode(state.gameMode());
            spectator.teleport(state.location());
        }
        spectator.sendMessage(plugin.getConfig()
                .getString("messages.spectate-leave", "§7You stopped spectating."));
    }

    /**
     * Removes all spectators of a match (called when match ends).
     */
    public void removeMatchSpectators(DuelMatch match) {
        Set<UUID> toRemove = new HashSet<>();
        for (Map.Entry<UUID, UUID> entry : spectators.entrySet()) {
            if (match.involves(entry.getValue())) {
                toRemove.add(entry.getKey());
            }
        }
        for (UUID uuid : toRemove) {
            Player spectator = plugin.getServer().getPlayer(uuid);
            if (spectator != null && spectator.isOnline()) {
                stopSpectating(spectator);
            } else {
                spectators.remove(uuid);
                savedStates.remove(uuid);
            }
        }
    }

    public boolean isSpectating(UUID uuid)    { return spectators.containsKey(uuid); }
    public int     getSpectatorCount()        { return spectators.size(); }
    public Set<UUID> getSpectators(DuelMatch match) {
        Set<UUID> result = new HashSet<>();
        for (Map.Entry<UUID, UUID> e : spectators.entrySet()) {
            if (match.involves(e.getValue())) result.add(e.getKey());
        }
        return result;
    }

    // -----------------------------------------------------------------------

    private record SpectateState(Location location, GameMode gameMode) {}
}
