package com.bltz.duel.services;

import com.bltz.duel.BltzDuel;
import com.bltz.duel.models.ChallengeRequest;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages direct challenge requests between players.
 *
 * Flow:
 *  /duel challenge <player> → sendChallenge()
 *  /duel accept             → acceptChallenge() → MatchService.startMatch()
 *  /duel deny               → denyChallenge()
 */
public final class ChallengeService {

    private final BltzDuel    plugin;
    private final MatchService matchService;

    /** challenged UUID → pending request */
    private final Map<UUID, ChallengeRequest> pending = new ConcurrentHashMap<>();

    public ChallengeService(BltzDuel plugin, MatchService matchService) {
        this.plugin       = plugin;
        this.matchService = matchService;
    }

    // -----------------------------------------------------------------------

    /**
     * Sends a challenge from one player to another.
     * @return false if either player is in a match/queue or already has a pending challenge.
     */
    public boolean sendChallenge(Player challenger, Player challenged) {
        UUID cId = challenger.getUniqueId();
        UUID tId = challenged.getUniqueId();

        // Already has pending challenge to this player
        ChallengeRequest existing = pending.get(tId);
        if (existing != null && existing.getChallenger().equals(cId) && !existing.isExpired()) {
            return false;
        }

        long expireSeconds = plugin.getConfig().getLong("challenge.expire-seconds", 30L);
        ChallengeRequest request = new ChallengeRequest(cId, tId, expireSeconds);
        pending.put(tId, request);

        // Auto-expire
        new BukkitRunnable() {
            @Override public void run() {
                ChallengeRequest r = pending.get(tId);
                if (r != null && r.getChallenger().equals(cId) && r.isExpired()) {
                    pending.remove(tId);
                    Player c = plugin.getServer().getPlayer(cId);
                    if (c != null && c.isOnline()) {
                        c.sendMessage(plugin.getConfig()
                                .getString("messages.challenge-expired", "§cChallenge expired."));
                    }
                }
            }
        }.runTaskLater(plugin, expireSeconds * 20L);

        return true;
    }

    /**
     * Accepts the pending challenge for the given player.
     * @return true if accepted and match started.
     */
    public boolean acceptChallenge(Player challenged) {
        UUID tId = challenged.getUniqueId();
        ChallengeRequest request = pending.get(tId);

        if (request == null || request.isExpired()) {
            pending.remove(tId);
            return false;
        }

        Player challenger = plugin.getServer().getPlayer(request.getChallenger());
        if (challenger == null || !challenger.isOnline()) {
            pending.remove(tId);
            return false;
        }

        pending.remove(tId);

        // Notify challenger
        challenger.sendMessage(plugin.getConfig()
                .getString("messages.challenge-accepted", "§aChallenge accepted!")
                .replace("{player}", challenged.getName()));

        // Start the match
        matchService.startMatch(challenger, challenged);
        return true;
    }

    /**
     * Denies the pending challenge.
     */
    public boolean denyChallenge(Player challenged) {
        UUID tId = challenged.getUniqueId();
        ChallengeRequest request = pending.remove(tId);
        if (request == null) return false;

        Player challenger = plugin.getServer().getPlayer(request.getChallenger());
        if (challenger != null && challenger.isOnline()) {
            challenger.sendMessage(plugin.getConfig()
                    .getString("messages.challenge-denied", "§cChallenge denied.")
                    .replace("{player}", challenged.getName()));
        }
        return true;
    }

    public boolean hasPendingChallenge(UUID uuid) {
        ChallengeRequest r = pending.get(uuid);
        if (r == null) return false;
        if (r.isExpired()) { pending.remove(uuid); return false; }
        return true;
    }

    public ChallengeRequest getPendingChallenge(UUID uuid) {
        ChallengeRequest r = pending.get(uuid);
        if (r == null) return null;
        if (r.isExpired()) { pending.remove(uuid); return null; }
        return r;
    }
}
