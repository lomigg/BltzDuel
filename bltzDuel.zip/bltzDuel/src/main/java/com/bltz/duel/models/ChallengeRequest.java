package com.bltz.duel.models;

import java.util.UUID;

/**
 * Represents a pending direct challenge between two players.
 */
public final class ChallengeRequest {

    private final UUID   challenger;
    private final UUID   challenged;
    private final long   createdAt;
    private final long   expireMs;

    public ChallengeRequest(UUID challenger, UUID challenged, long expireSeconds) {
        this.challenger = challenger;
        this.challenged = challenged;
        this.createdAt  = System.currentTimeMillis();
        this.expireMs   = expireSeconds * 1000L;
    }

    public UUID getChallenger()  { return challenger; }
    public UUID getChallenged()  { return challenged;  }
    public long getCreatedAt()   { return createdAt;   }

    public boolean isExpired() {
        return System.currentTimeMillis() - createdAt >= expireMs;
    }

    public long getRemainingSeconds() {
        long remaining = expireMs - (System.currentTimeMillis() - createdAt);
        return Math.max(0, remaining / 1000L);
    }
}
