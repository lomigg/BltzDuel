package com.bltz.duel.commands;

import com.bltz.duel.BltzDuel;
import com.bltz.duel.models.DuelMatch;
import com.bltz.duel.models.PlayerStats;
import com.bltz.duel.services.*;
import com.bltz.duel.utils.MessageUtil;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * /duel command — all subcommands.
 *
 * <pre>
 * /duel queue|q          — Join matchmaking queue
 * /duel leave|l          — Leave queue or cancel
 * /duel challenge <p>    — Challenge a player directly
 * /duel accept           — Accept pending challenge
 * /duel deny             — Deny pending challenge
 * /duel stats [player]   — View K/D stats
 * /duel top              — Top 10 leaderboard
 * /duel spectate <p>     — Spectate a player's match
 * /duel pos              — Your queue position
 * /duel help             — Help
 * /duel reload           — Reload config (admin)
 * </pre>
 */
public final class DuelCommand implements CommandExecutor, TabCompleter {

    private final BltzDuel       plugin;
    private final QueueService   queueService;
    private final MatchService   matchService;
    private final StatsService   statsService;
    private final CooldownService cooldownService;
    private final ChallengeService challengeService;
    private final SpectateService  spectateService;

    public DuelCommand(BltzDuel plugin, QueueService queueService,
                       MatchService matchService, StatsService statsService,
                       CooldownService cooldownService, ChallengeService challengeService,
                       SpectateService spectateService) {
        this.plugin           = plugin;
        this.queueService     = queueService;
        this.matchService     = matchService;
        this.statsService     = statsService;
        this.cooldownService  = cooldownService;
        this.challengeService = challengeService;
        this.spectateService  = spectateService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command,
                             String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cPlayers only.");
            return true;
        }
        if (!player.hasPermission("bltzduel.use")) {
            player.sendMessage(msg("messages.no-permission"));
            return true;
        }

        String sub = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "help";

        switch (sub) {
            case "queue",     "q"         -> handleQueue(player);
            case "leave",     "l"         -> handleLeave(player);
            case "challenge", "c"         -> handleChallenge(player, args);
            case "accept",    "a"         -> handleAccept(player);
            case "deny",      "d"         -> handleDeny(player);
            case "stats",     "s"         -> handleStats(player, args);
            case "top",       "leaderboard" -> handleTop(player);
            case "spectate",  "spec"      -> handleSpectate(player, args);
            case "pos",       "position"  -> handlePos(player);
            case "reload"                 -> handleReload(player);
            default                       -> sendHelp(player, label);
        }
        return true;
    }

    // -----------------------------------------------------------------------
    //  Handlers
    // -----------------------------------------------------------------------

    private void handleQueue(Player player) {
        UUID uuid = player.getUniqueId();

        if (matchService.isInMatch(uuid)) {
            player.sendMessage(msg("messages.already-in-match")); return;
        }
        if (spectateService.isSpectating(uuid)) {
            spectateService.stopSpectating(player); return;
        }
        if (cooldownService.isOnCooldown(uuid) && !player.hasPermission("bltzduel.bypass-cooldown")) {
            long rem = cooldownService.getRemainingSeconds(uuid);
            player.sendMessage(msg("messages.cooldown").replace("{time}", String.valueOf(rem)));
            return;
        }
        if (queueService.isInQueue(uuid)) {
            int pos = queueService.getPosition(uuid);
            player.sendMessage(msg("messages.already-queued").replace("{pos}", String.valueOf(pos)));
            return;
        }

        queueService.addToQueue(player);
        int pos = queueService.getPosition(uuid);
        player.sendMessage(msg("messages.joined-queue").replace("{pos}", String.valueOf(pos)));
    }

    private void handleLeave(Player player) {
        UUID uuid = player.getUniqueId();
        if (spectateService.isSpectating(uuid)) {
            spectateService.stopSpectating(player); return;
        }
        if (!queueService.isInQueue(uuid)) {
            player.sendMessage(msg("messages.not-in-queue")); return;
        }
        queueService.removeFromQueue(uuid);
        player.sendMessage(msg("messages.left-queue"));
    }

    private void handleChallenge(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage("§cUsage: /duel challenge <player>"); return;
        }
        Player target = plugin.getServer().getPlayerExact(args[1]);
        if (target == null || !target.isOnline()) {
            player.sendMessage("§c[1v1] Player not found or offline."); return;
        }
        if (target.equals(player)) {
            player.sendMessage("§c[1v1] You cannot challenge yourself."); return;
        }
        if (matchService.isInMatch(player.getUniqueId()) || matchService.isInMatch(target.getUniqueId())) {
            player.sendMessage(msg("messages.already-in-match")); return;
        }

        boolean sent = challengeService.sendChallenge(player, target);
        if (!sent) { player.sendMessage("§c[1v1] Challenge already pending."); return; }

        player.sendMessage(msg("messages.challenge-sent").replace("{player}", target.getName()));
        target.sendMessage(msg("messages.challenge-received").replace("{player}", player.getName()));
    }

    private void handleAccept(Player player) {
        if (!challengeService.hasPendingChallenge(player.getUniqueId())) {
            player.sendMessage(msg("messages.no-challenge")); return;
        }
        if (!challengeService.acceptChallenge(player)) {
            player.sendMessage(msg("messages.no-challenge"));
        }
    }

    private void handleDeny(Player player) {
        if (!challengeService.hasPendingChallenge(player.getUniqueId())) {
            player.sendMessage(msg("messages.no-challenge")); return;
        }
        challengeService.denyChallenge(player);
        player.sendMessage("§c[1v1] Challenge denied.");
    }

    private void handleStats(Player player, String[] args) {
        String targetName = args.length > 1 ? args[1] : player.getName();
        Player target = plugin.getServer().getPlayerExact(targetName);
        UUID targetUUID = target != null ? target.getUniqueId() : resolveOfflineUUID(targetName);

        if (targetUUID == null) {
            player.sendMessage("§c[1v1] Player not found: §e" + targetName); return;
        }

        PlayerStats s = statsService.getStats(targetUUID, targetName);
        player.sendMessage("§8§m-------- §6" + s.getLastName() + "'s Stats §8§m--------");
        player.sendMessage("§eWins:    §a" + s.getWins());
        player.sendMessage("§eLosses:  §c" + s.getLosses());
        player.sendMessage("§eMatches: §7" + s.getTotalMatches());
        player.sendMessage(String.format("§eK/D:     §6%.2f", s.getKD()));
        player.sendMessage("§8§m------------------------------------");
    }

    private void handleTop(Player player) {
        List<PlayerStats> top = statsService.getTopPlayers(10);
        player.sendMessage("§8§m------- §6Top 10 — Duel Rankings §8§m-------");
        if (top.isEmpty()) { player.sendMessage("§7No matches played yet."); }
        else {
            for (int i = 0; i < top.size(); i++) {
                PlayerStats s = top.get(i);
                player.sendMessage(String.format("§6#%d §e%-16s §aW:§f%d §cL:§f%d §6KD:§f%.2f",
                        i + 1, s.getLastName(), s.getWins(), s.getLosses(), s.getKD()));
            }
        }
        player.sendMessage("§8§m--------------------------------------");
    }

    private void handleSpectate(Player player, String[] args) {
        if (!player.hasPermission("bltzduel.spectate")) {
            player.sendMessage(msg("messages.no-permission")); return;
        }
        if (args.length < 2) {
            player.sendMessage("§cUsage: /duel spectate <player>"); return;
        }
        Player target = plugin.getServer().getPlayerExact(args[1]);
        if (target == null || !target.isOnline()) {
            player.sendMessage("§c[1v1] Player not found or offline."); return;
        }
        DuelMatch match = matchService.getMatch(target.getUniqueId());
        if (match == null) {
            player.sendMessage(msg("messages.no-match")); return;
        }
        if (matchService.isInMatch(player.getUniqueId())) {
            player.sendMessage(msg("messages.already-in-match")); return;
        }
        spectateService.startSpectating(player, target, match);
    }

    private void handlePos(Player player) {
        if (!queueService.isInQueue(player.getUniqueId())) {
            player.sendMessage(msg("messages.not-in-queue")); return;
        }
        int pos   = queueService.getPosition(player.getUniqueId());
        int total = queueService.getQueueSize();
        player.sendMessage(msg("messages.queue-position")
                .replace("{pos}",   String.valueOf(pos))
                .replace("{total}", String.valueOf(total)));
    }

    private void handleReload(Player player) {
        if (!player.hasPermission("bltzduel.admin")) {
            player.sendMessage(msg("messages.no-permission")); return;
        }
        plugin.reloadConfig();
        player.sendMessage(msg("messages.config-reloaded"));
    }

    private void sendHelp(Player player, String label) {
        player.sendMessage("§8§m-------- §6bltzDuel Help §8§m--------");
        player.sendMessage("§e/" + label + " queue            §7→ Join matchmaking");
        player.sendMessage("§e/" + label + " leave            §7→ Leave queue");
        player.sendMessage("§e/" + label + " challenge <p>    §7→ Challenge a player");
        player.sendMessage("§e/" + label + " accept/deny      §7→ Accept/deny challenge");
        player.sendMessage("§e/" + label + " spectate <p>     §7→ Spectate a match");
        player.sendMessage("§e/" + label + " stats [player]   §7→ View K/D stats");
        player.sendMessage("§e/" + label + " top              §7→ Leaderboard");
        player.sendMessage("§e/" + label + " pos              §7→ Queue position");
        player.sendMessage("§8§m------------------------------------");
    }

    // -----------------------------------------------------------------------

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command,
                                      String alias, String[] args) {
        if (args.length == 1) {
            return List.of("queue","leave","challenge","accept","deny","stats","top","spectate","pos","help")
                    .stream().filter(s -> s.startsWith(args[0].toLowerCase())).toList();
        }
        if (args.length == 2) {
            if (args[0].equalsIgnoreCase("challenge") || args[0].equalsIgnoreCase("spectate")
                    || args[0].equalsIgnoreCase("stats")) {
                return plugin.getServer().getOnlinePlayers().stream()
                        .map(Player::getName)
                        .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                        .toList();
            }
        }
        return List.of();
    }

    private String msg(String key) { return plugin.getConfig().getString(key, ""); }

    private UUID resolveOfflineUUID(String name) {
        return statsService.getTopPlayers(Integer.MAX_VALUE).stream()
                .filter(s -> s.getLastName().equalsIgnoreCase(name))
                .map(PlayerStats::getUuid)
                .findFirst().orElse(null);
    }
}
