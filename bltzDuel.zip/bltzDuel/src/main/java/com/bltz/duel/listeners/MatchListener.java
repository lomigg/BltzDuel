package com.bltz.duel.listeners;

import com.bltz.duel.BltzDuel;
import com.bltz.duel.models.DuelMatch;
import com.bltz.duel.services.MatchService;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.util.UUID;

public final class MatchListener implements Listener {

    private final BltzDuel     plugin;
    private final MatchService matchService;

    public MatchListener(BltzDuel plugin, MatchService matchService) {
        this.plugin       = plugin;
        this.matchService = matchService;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        Player dead = event.getEntity();
        if (!matchService.isInMatch(dead.getUniqueId())) return;

        DuelMatch match = matchService.getMatch(dead.getUniqueId());
        if (match == null) return;

        if (plugin.getConfig().getBoolean("match.keep-inventory", true)) {
            event.setKeepInventory(true);
            event.getDrops().clear();
            event.setKeepLevel(true);
            event.setDroppedExp(0);
        }
        event.setDeathMessage(null);

        UUID opponentUUID = match.getOpponent(dead.getUniqueId());
        Player killer = dead.getKiller();
        UUID winner = (killer != null && matchService.isInMatch(killer.getUniqueId()))
                ? killer.getUniqueId() : opponentUUID;

        matchService.endMatch(winner, dead.getUniqueId());

        int delay = plugin.getConfig().getInt("match.return-delay", 3) * 20;
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (dead.isOnline()) {
                dead.spigot().respawn();
                plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                    if (dead.isOnline()) {
                        var origin = match.getOrigin(dead.getUniqueId());
                        if (origin != null) dead.teleport(origin);
                    }
                }, 5L);
            }
        }, 1L);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity()  instanceof Player victim))   return;
        if (!matchService.isInMatch(attacker.getUniqueId())) return;
        if (!matchService.isInMatch(victim.getUniqueId()))   return;
        matchService.tagCombat(attacker.getUniqueId());
        matchService.tagCombat(victim.getUniqueId());
    }
}
