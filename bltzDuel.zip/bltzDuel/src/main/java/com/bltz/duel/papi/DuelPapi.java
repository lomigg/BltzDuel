package com.bltz.duel.papi;

import com.bltz.duel.BltzDuel;
import com.bltz.duel.models.PlayerStats;
import com.bltz.duel.services.MatchService;
import com.bltz.duel.services.QueueService;
import com.bltz.duel.services.StatsService;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/**
 * PlaceholderAPI expansion for bltzDuel.
 *
 * Available placeholders:
 *  %bltzduel_wins%         — Player's wins
 *  %bltzduel_losses%       — Player's losses
 *  %bltzduel_kd%           — K/D ratio
 *  %bltzduel_matches%      — Total matches
 *  %bltzduel_in_match%     — true/false in match
 *  %bltzduel_in_queue%     — true/false in queue
 *  %bltzduel_queue_pos%    — Queue position
 *  %bltzduel_queue_size%   — Total players in queue
 *  %bltzduel_active_matches% — Active match count
 */
public final class DuelPapi extends PlaceholderExpansion {

    private final BltzDuel     plugin;
    private final StatsService statsService;
    private final MatchService matchService;
    private final QueueService queueService;

    public DuelPapi(BltzDuel plugin, StatsService statsService,
                    MatchService matchService, QueueService queueService) {
        this.plugin        = plugin;
        this.statsService  = statsService;
        this.matchService  = matchService;
        this.queueService  = queueService;
    }

    @Override public @NotNull String getIdentifier() { return "bltzduel";  }
    @Override public @NotNull String getAuthor()     { return "bltz";      }
    @Override public @NotNull String getVersion()    { return plugin.getDescription().getVersion(); }
    @Override public boolean persist()               { return true;        }

    @Override
    public String onPlaceholderRequest(Player player, @NotNull String params) {
        if (player == null) return "";
        PlayerStats stats = statsService.getStats(player.getUniqueId(), player.getName());

        return switch (params.toLowerCase()) {
            case "wins"           -> String.valueOf(stats.getWins());
            case "losses"         -> String.valueOf(stats.getLosses());
            case "kd"             -> String.format("%.2f", stats.getKD());
            case "matches"        -> String.valueOf(stats.getTotalMatches());
            case "in_match"       -> String.valueOf(matchService.isInMatch(player.getUniqueId()));
            case "in_queue"       -> String.valueOf(queueService.isInQueue(player.getUniqueId()));
            case "queue_pos"      -> {
                int pos = queueService.getPosition(player.getUniqueId());
                yield pos == -1 ? "N/A" : String.valueOf(pos);
            }
            case "queue_size"     -> String.valueOf(queueService.getQueueSize());
            case "active_matches" -> String.valueOf(matchService.getActiveMatchCount());
            default               -> null;
        };
    }
}
