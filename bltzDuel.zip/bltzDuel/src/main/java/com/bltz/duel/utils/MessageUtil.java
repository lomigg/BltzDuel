package com.bltz.duel.utils;

import com.bltz.duel.BltzDuel;
import org.bukkit.command.CommandSender;

public final class MessageUtil {

    private MessageUtil() {}

    public static String get(BltzDuel plugin, String key, String... replacements) {
        String msg = plugin.getConfig().getString(key, "");
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            msg = msg.replace(replacements[i], replacements[i + 1]);
        }
        return msg;
    }

    public static void send(BltzDuel plugin, CommandSender sender, String key, String... replacements) {
        String msg = get(plugin, key, replacements);
        if (!msg.isEmpty()) sender.sendMessage(msg);
    }
}
