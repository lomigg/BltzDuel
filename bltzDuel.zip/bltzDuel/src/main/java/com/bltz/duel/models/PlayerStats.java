package com.bltz.duel.models;

import java.util.UUID;

public final class PlayerStats {

    private final UUID   uuid;
    private       String lastName;
    private int wins;
    private int losses;

    public PlayerStats(UUID uuid, String lastName, int wins, int losses) {
        this.uuid     = uuid;
        this.lastName = lastName;
        this.wins     = wins;
        this.losses   = losses;
    }

    public UUID   getUuid()      { return uuid;     }
    public String getLastName()  { return lastName; }
    public int    getWins()      { return wins;     }
    public int    getLosses()    { return losses;   }

    public void setLastName(String n) { this.lastName = n; }
    public void addWin()   { wins++;   }
    public void addLoss()  { losses++; }

    public double getKD()           { return losses == 0 ? wins : (double) wins / losses; }
    public int    getTotalMatches() { return wins + losses; }
    public int    getWinStreak()    { return wins; } // simplified
}
