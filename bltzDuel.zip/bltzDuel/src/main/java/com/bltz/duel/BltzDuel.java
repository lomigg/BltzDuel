package com.bltz.duel;

import com.bltz.duel.commands.DuelCommand;
import com.bltz.duel.listeners.CombatTagListener;
import com.bltz.duel.listeners.MatchListener;
import com.bltz.duel.listeners.PlayerSessionListener;
import com.bltz.duel.papi.DuelPapi;
import com.bltz.duel.services.*;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;

public final class BltzDuel extends JavaPlugin {

    private CooldownService  cooldownService;
    private StatsService     statsService;
    private SpectateService  spectateService;
    private MatchService     matchService;
    private QueueService     queueService;
    private ChallengeService challengeService;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        // Services
        this.cooldownService  = new CooldownService();
        this.statsService     = new StatsService(this);
        this.spectateService  = new SpectateService(this);
        this.matchService     = new MatchService(this, statsService, cooldownService, spectateService);
        this.queueService     = new QueueService(this, matchService, cooldownService);
        this.challengeService = new ChallengeService(this, matchService);

        // Command
        var cmd = Objects.requireNonNull(getCommand("duel"));
        var handler = new DuelCommand(this, queueService, matchService, statsService,
                cooldownService, challengeService, spectateService);
        cmd.setExecutor(handler);
        cmd.setTabCompleter(handler);

        // Listeners
        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new MatchListener(this, matchService), this);
        pm.registerEvents(new CombatTagListener(this, matchService), this);
        pm.registerEvents(new PlayerSessionListener(matchService, queueService, spectateService), this);

        // PlaceholderAPI
        if (pm.getPlugin("PlaceholderAPI") != null) {
            new DuelPapi(this, statsService, matchService, queueService).register();
            getLogger().info("PlaceholderAPI hooked.");
        }

        // Queue processor
        queueService.startProcessor();

        getLogger().info("bltzDuel v" + getDescription().getVersion() + " enabled!");
    }

    @Override
    public void onDisable() {
        if (queueService  != null) queueService.shutdown();
        if (statsService  != null) statsService.saveAll();
        getLogger().info("bltzDuel disabled.");
    }

    public CooldownService  getCooldownService()  { return cooldownService;  }
    public StatsService     getStatsService()     { return statsService;     }
    public SpectateService  getSpectateService()  { return spectateService;  }
    public MatchService     getMatchService()     { return matchService;     }
    public QueueService     getQueueService()     { return queueService;     }
    public ChallengeService getChallengeService() { return challengeService; }
}
