package com.bltz.duel.services;

import com.bltz.duel.BltzDuel;
import com.bltz.duel.models.DuelMatch;
import com.bltz.duel.utils.LocationFinder;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Core match lifecycle manager.
 *
 * Flow:
 *  startMatch() → find locations → 3s countdown → teleport → ACTIVE
 *  endMatch()   → stats → return → broadcast
 *  handleLogout() → forfeit if combat-tagged
 */
public final class MatchService {

    private final BltzDuel      plugin;
    private final StatsService  statsService;
    private final CooldownService cooldownService;
    private final SpectateService spectateService;
    private final LocationFinder  locationFinder;

    /** Both player UUIDs map to the same DuelMatch */
    private final Map<UUID, DuelMatch> activeMatches = new ConcurrentHashMap<>();

    public MatchService(BltzDuel plugin, StatsService statsService,
                        CooldownService cooldownService, SpectateService spectateService) {
        this.plugin          = plugin;
        this.statsService    = statsService;
        this.cooldownService = cooldownService;
        this.spectateService = spectateService;
        this.locationFinder  = new LocationFinder(plugin);
    }

    // -----------------------------------------------------------------------
    //  Start
    // -----------------------------------------------------------------------

    public void startMatch(Player p1, Player p2) {
        p1.sendMessage(msg("messages.match-found"));
        p2.sendMessage(msg("messages.match-found"));

        plugin.getServer().getScheduler().runTask(plugin, () -> {
            World world = resolveWorld(p1);
            double minDist = plugin.getConfig().getDouble("rtp.min-spawn-distance", 20.0);
            Location[] locs = locationFinder.findPair(world, minDist);

            if (locs == null) {
                String fail = "§c[1v1] Could not find arena. Try again.";
                p1.sendMessage(fail); p2.sendMessage(fail);
                return;
            }

            Location origin1 = p1.getLocation().clone();
            Location origin2 = p2.getLocation().clone();
            DuelMatch match  = new DuelMatch(p1.getUniqueId(), p2.getUniqueId(), origin1, origin2);

            activeMatches.put(p1.getUniqueId(), match);
            activeMatches.put(p2.getUniqueId(), match);

            int countdownSecs = plugin.getConfig().getInt("match.countdown", 3);

            new BukkitRunnable() {
                int tick = countdownSecs;
                @Override public void run() {
                    if (!p1.isOnline() || !p2.isOnline()) {
                        activeMatches.remove(p1.getUniqueId());
                        activeMatches.remove(p2.getUniqueId());
                        if (p1.isOnline()) p1.sendMessage("§c[1v1] Opponent disconnected.");
                        if (p2.isOnline()) p2.sendMessage("§c[1v1] Opponent disconnected.");
                        cancel(); return;
                    }
                    if (tick > 0) {
                        String cd = "§6[1v1] §eTeleporting in §c" + tick + "§e...";
                        p1.sendMessage(cd); p2.sendMessage(cd);
                        tick--;
                    } else {
                        doTeleport(p1, p2, locs[0], locs[1], match);
                        cancel();
                    }
                }
            }.runTaskTimer(plugin, 0L, 20L);
        });
    }

    private void doTeleport(Player p1, Player p2, Location loc1, Location loc2, DuelMatch match) {
        p1.teleport(loc1); p2.teleport(loc2);
        match.setState(DuelMatch.State.ACTIVE);
        match.tagCombat(p1.getUniqueId());
        match.tagCombat(p2.getUniqueId());

        spawnParticles(loc1); spawnParticles(loc2);
        playSound(p1, loc1, "effects.sound-teleport");
        playSound(p2, loc2, "effects.sound-teleport");

        p1.sendMessage(msg("messages.match-start").replace("{opponent}", p2.getName()));
        p2.sendMessage(msg("messages.match-start").replace("{opponent}", p1.getName()));

        playSound(p1, loc1, "effects.sound-match-start");
        playSound(p2, loc2, "effects.sound-match-start");
    }

    // -----------------------------------------------------------------------
    //  End
    // -----------------------------------------------------------------------

    public void endMatch(UUID winner, UUID loser) {
        DuelMatch match = activeMatches.remove(winner);
        if (match == null) match = activeMatches.remove(loser);
        if (match == null) return;
        activeMatches.remove(winner);
        activeMatches.remove(loser);
        match.setState(DuelMatch.State.ENDED);

        Player winnerPlayer = plugin.getServer().getPlayer(winner);
        Player loserPlayer  = plugin.getServer().getPlayer(loser);

        String winnerName = winnerPlayer != null ? winnerPlayer.getName() : winner.toString().substring(0, 8);
        String loserName  = loserPlayer  != null ? loserPlayer.getName()  : loser.toString().substring(0, 8);

        // Stats
        statsService.recordWin(winner,  winnerName);
        statsService.recordLoss(loser,  loserName);
        statsService.saveAll();

        // Cooldown
        long cd = plugin.getConfig().getLong("match.cooldown", 60L);
        cooldownService.setCooldown(winner, cd);
        cooldownService.setCooldown(loser,  cd);

        // Messages & effects
        if (winnerPlayer != null && winnerPlayer.isOnline()) {
            winnerPlayer.sendMessage(msg("messages.you-win").replace("{opponent}", loserName));
            playSound(winnerPlayer, winnerPlayer.getLocation(), "effects.sound-win");
            DuelMatch finalMatch = match;
            Location winOrigin = finalMatch.getOrigin(winner);
            int returnDelay = plugin.getConfig().getInt("match.return-delay", 3) * 20;
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (winnerPlayer.isOnline() && winOrigin != null) winnerPlayer.teleport(winOrigin);
            }, returnDelay);
        }

        if (loserPlayer != null && loserPlayer.isOnline()) {
            loserPlayer.sendMessage(msg("messages.you-lose").replace("{opponent}", winnerName));
            playSound(loserPlayer, loserPlayer.getLocation(), "effects.sound-lose");
        }

        // Broadcast
        plugin.getServer().broadcastMessage(
                "§8[§c1v1§8] §e" + winnerName + " §6defeated §e" + loserName + " §6in §e"
                + match.getDurationSeconds() + "s§6!");

        // Remove spectators
        spectateService.removeMatchSpectators(match);
    }

    // -----------------------------------------------------------------------
    //  Logout handling
    // -----------------------------------------------------------------------

    public void handleLogout(UUID uuid, String playerName) {
        DuelMatch match = activeMatches.get(uuid);
        if (match == null) return;

        boolean killOnLogout = plugin.getConfig().getBoolean("match.kill-on-logout", true);
        long expireMs = plugin.getConfig().getLong("match.combat-tag-seconds", 15L) * 1_000L;
        UUID opponentUUID = match.getOpponent(uuid);

        if (killOnLogout && match.isCombatTagged(uuid, expireMs)) {
            plugin.getServer().broadcastMessage(
                    msg("messages.logout-killed").replace("{player}", playerName));
            endMatch(opponentUUID, uuid);
        } else {
            activeMatches.remove(uuid);
            activeMatches.remove(opponentUUID);
            match.setState(DuelMatch.State.ENDED);
            Player opponent = plugin.getServer().getPlayer(opponentUUID);
            if (opponent != null && opponent.isOnline()) {
                opponent.sendMessage("§c[1v1] Opponent disconnected. Match cancelled.");
                Location origin = match.getOrigin(opponentUUID);
                if (origin != null) opponent.teleport(origin);
            }
            spectateService.removeMatchSpectators(match);
        }
    }

    // -----------------------------------------------------------------------
    //  Combat tag
    // -----------------------------------------------------------------------

    public void tagCombat(UUID uuid) {
        DuelMatch m = activeMatches.get(uuid);
        if (m != null) m.tagCombat(uuid);
    }

    public boolean isCombatTagged(UUID uuid) {
        DuelMatch m = activeMatches.get(uuid);
        if (m == null) return false;
        long expireMs = plugin.getConfig().getLong("match.combat-tag-seconds", 15L) * 1_000L;
        return m.isCombatTagged(uuid, expireMs);
    }

    // -----------------------------------------------------------------------
    //  Queries
    // -----------------------------------------------------------------------

    public boolean     isInMatch(UUID uuid)         { return activeMatches.containsKey(uuid); }
    public DuelMatch   getMatch(UUID uuid)           { return activeMatches.get(uuid);         }
    public int         getActiveMatchCount()         { return activeMatches.size() / 2;        }
    public Collection<DuelMatch> getActiveMatches()  { return new HashSet<>(activeMatches.values()); }

    // -----------------------------------------------------------------------
    //  Helpers
    // -----------------------------------------------------------------------

    private World resolveWorld(Player fallback) {
        String name = plugin.getConfig().getString("rtp.world", "world");
        World w = plugin.getServer().getWorld(name);
        return w != null ? w : fallback.getWorld();
    }

    private void spawnParticles(Location loc) {
        if (!plugin.getConfig().getBoolean("effects.enabled", true)) return;
        try {
            Particle p = Particle.valueOf(
                    plugin.getConfig().getString("effects.particle", "PORTAL").toUpperCase());
            loc.getWorld().spawnParticle(p, loc.clone().add(0,1,0), 50, 0.5, 1.0, 0.5, 0.05);
        } catch (IllegalArgumentException ignored) {}
    }

    private void playSound(Player player, Location loc, String configKey) {
        if (!plugin.getConfig().getBoolean("effects.enabled", true)) return;
        try {
            Sound s = Sound.valueOf(
                    plugin.getConfig().getString(configKey, "ENTITY_ENDERMAN_TELEPORT").toUpperCase());
            player.playSound(loc, s, 1f, 1f);
        } catch (IllegalArgumentException ignored) {}
    }

    private String msg(String key) {
        return plugin.getConfig().getString(key, "");
    }
}
