package com.bltz.duel.services;

import com.bltz.duel.BltzDuel;
import com.bltz.duel.models.QueueEntry;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;

public final class QueueService {

    private final BltzDuel       plugin;
    private final MatchService   matchService;
    private final CooldownService cooldownService;

    private final Queue<QueueEntry> queue   = new ConcurrentLinkedQueue<>();
    private final Set<UUID>         inQueue = Collections.synchronizedSet(new HashSet<>());
    private BukkitTask processorTask;

    public QueueService(BltzDuel plugin, MatchService matchService, CooldownService cooldownService) {
        this.plugin          = plugin;
        this.matchService    = matchService;
        this.cooldownService = cooldownService;
    }

    public void startProcessor() {
        long interval = plugin.getConfig().getLong("queue.process-interval-ticks", 20L);
        processorTask = new BukkitRunnable() {
            @Override public void run() { processQueue(); }
        }.runTaskTimer(plugin, 20L, interval);
    }

    public void shutdown() {
        if (processorTask != null) { processorTask.cancel(); processorTask = null; }
    }

    // -----------------------------------------------------------------------

    public boolean addToQueue(Player player) {
        UUID uuid = player.getUniqueId();
        if (inQueue.contains(uuid))               return false;
        if (matchService.isInMatch(uuid))         return false;
        if (cooldownService.isOnCooldown(uuid)
                && !player.hasPermission("bltzduel.bypass-cooldown")) return false;

        queue.offer(new QueueEntry(uuid));
        inQueue.add(uuid);
        return true;
    }

    public void removeFromQueue(UUID uuid) {
        queue.removeIf(e -> e.getPlayerUUID().equals(uuid));
        inQueue.remove(uuid);
    }

    public boolean isInQueue(UUID uuid) { return inQueue.contains(uuid); }

    public int getPosition(UUID uuid) {
        int pos = 1;
        for (QueueEntry e : queue) {
            if (e.getPlayerUUID().equals(uuid)) return pos;
            pos++;
        }
        return -1;
    }

    public int getQueueSize() { return queue.size(); }

    // -----------------------------------------------------------------------

    private void processQueue() {
        if (queue.size() < 2) return;
        QueueEntry e1 = queue.poll(); if (e1 == null) return;
        QueueEntry e2 = queue.poll(); if (e2 == null) { queue.offer(e1); return; }

        inQueue.remove(e1.getPlayerUUID());
        inQueue.remove(e2.getPlayerUUID());

        Player p1 = plugin.getServer().getPlayer(e1.getPlayerUUID());
        Player p2 = plugin.getServer().getPlayer(e2.getPlayerUUID());

        if (p1 == null || !p1.isOnline()) { if (p2 != null) requeue(p2, e2); return; }
        if (p2 == null || !p2.isOnline()) { requeue(p1, e1); return; }

        matchService.startMatch(p1, p2);
    }

    private void requeue(Player p, QueueEntry e) {
        queue.offer(e);
        inQueue.add(p.getUniqueId());
    }
}
