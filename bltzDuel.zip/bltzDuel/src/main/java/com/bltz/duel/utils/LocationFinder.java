package com.bltz.duel.utils;

import com.bltz.duel.BltzDuel;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

import java.util.Random;
import java.util.Set;

/**
 * Finds safe random locations for duel arenas.
 * Must be called on the main server thread.
 */
public final class LocationFinder {

    private static final Set<Material> UNSAFE = Set.of(
            Material.WATER, Material.LAVA, Material.MAGMA_BLOCK,
            Material.CACTUS, Material.FIRE, Material.SOUL_FIRE, Material.POWDER_SNOW
    );

    private static final Set<Material> LEAVES = Set.of(
            Material.OAK_LEAVES, Material.BIRCH_LEAVES, Material.SPRUCE_LEAVES,
            Material.JUNGLE_LEAVES, Material.ACACIA_LEAVES, Material.DARK_OAK_LEAVES,
            Material.MANGROVE_LEAVES, Material.CHERRY_LEAVES, Material.AZALEA_LEAVES
    );

    private static final Set<Material> PASSABLE = Set.of(
            Material.AIR, Material.CAVE_AIR, Material.SHORT_GRASS, Material.TALL_GRASS,
            Material.FERN, Material.LARGE_FERN, Material.DEAD_BUSH, Material.SNOW
    );

    private final BltzDuel plugin;
    private final Random   random = new Random();

    public LocationFinder(BltzDuel plugin) {
        this.plugin = plugin;
    }

    public Location findSafe(World world) {
        int minX = plugin.getConfig().getInt("rtp.min-x", -10000);
        int maxX = plugin.getConfig().getInt("rtp.max-x",  10000);
        int minZ = plugin.getConfig().getInt("rtp.min-z", -10000);
        int maxZ = plugin.getConfig().getInt("rtp.max-z",  10000);
        int max  = plugin.getConfig().getInt("rtp.max-attempts", 30);

        for (int i = 0; i < max; i++) {
            int x = minX + random.nextInt(maxX - minX);
            int z = minZ + random.nextInt(maxZ - minZ);
            Location loc = checkColumn(world, x, z);
            if (loc != null) return loc;
        }
        return null;
    }

    /**
     * Finds two safe locations separated by minDist blocks.
     */
    public Location[] findPair(World world, double minDist) {
        int max = plugin.getConfig().getInt("rtp.max-attempts", 30);
        for (int i = 0; i < max; i++) {
            Location a = findSafe(world);
            if (a == null) continue;
            Location b = findSafe(world);
            if (b == null) continue;
            if (a.distance(b) >= minDist) return new Location[]{a, b};
        }
        return null;
    }

    private Location checkColumn(World world, int x, int z) {
        int y = world.getHighestBlockYAt(x, z);
        if (y <= world.getMinHeight()) return null;

        Material ground = world.getBlockAt(x, y,     z).getType();
        Material feet   = world.getBlockAt(x, y + 1, z).getType();
        Material head   = world.getBlockAt(x, y + 2, z).getType();

        if (!ground.isSolid())          return null;
        if (UNSAFE.contains(ground))    return null;
        if (LEAVES.contains(ground))    return null;
        if (!PASSABLE.contains(feet))   return null;
        if (!head.isAir())              return null;
        if (PASSABLE.contains(feet) && Set.of(Material.WATER, Material.LAVA).contains(feet)) return null;

        return new Location(world, x + 0.5, y + 1, z + 0.5, 0f, 0f);
    }
}
