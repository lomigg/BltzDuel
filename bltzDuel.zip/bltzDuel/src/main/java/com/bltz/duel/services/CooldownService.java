package com.bltz.duel.services;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class CooldownService {

    private final Map<UUID, Long> expiryMap = new ConcurrentHashMap<>();

    public void setCooldown(UUID uuid, long seconds) {
        expiryMap.put(uuid, System.currentTimeMillis() + seconds * 1_000L);
    }

    public boolean isOnCooldown(UUID uuid) {
        Long expiry = expiryMap.get(uuid);
        if (expiry == null) return false;
        if (System.currentTimeMillis() >= expiry) { expiryMap.remove(uuid); return false; }
        return true;
    }

    public long getRemainingSeconds(UUID uuid) {
        Long expiry = expiryMap.get(uuid);
        if (expiry == null) return 0L;
        return Math.max(0L, (expiry - System.currentTimeMillis()) / 1_000L);
    }

    public void removeCooldown(UUID uuid) {
        expiryMap.remove(uuid);
    }
}
