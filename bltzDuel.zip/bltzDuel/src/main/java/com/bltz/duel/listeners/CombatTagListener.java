package com.bltz.duel.listeners;

import com.bltz.duel.BltzDuel;
import com.bltz.duel.services.MatchService;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.Set;

public final class CombatTagListener implements Listener {

    private static final Set<String> BLOCKED = Set.of(
            "/tp","/teleport","/home","/spawn","/back",
            "/warp","/tpa","/tpaccept","/tpahere"
    );

    private final BltzDuel    plugin;
    private final MatchService matchService;

    public CombatTagListener(BltzDuel plugin, MatchService matchService) {
        this.plugin       = plugin;
        this.matchService = matchService;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (!matchService.isInMatch(player.getUniqueId())) return;
        if (!matchService.isCombatTagged(player.getUniqueId())) return;
        String cmd = event.getMessage().toLowerCase().split(" ")[0];
        if (BLOCKED.contains(cmd)) {
            event.setCancelled(true);
            player.sendMessage(plugin.getConfig()
                    .getString("messages.combat-tag", "§c⚔ You are in combat!"));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        Player player = event.getPlayer();
        if (!matchService.isInMatch(player.getUniqueId())) return;
        if (!matchService.isCombatTagged(player.getUniqueId())) return;
        var cause = event.getCause();
        if (cause == PlayerTeleportEvent.TeleportCause.PLUGIN) return;
        if (cause == PlayerTeleportEvent.TeleportCause.COMMAND) return;
        event.setCancelled(true);
        player.sendMessage(plugin.getConfig()
                .getString("messages.combat-tag", "§c⚔ You are in combat!"));
    }
}
